<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Quickivity - Dynamic Dashboard</title>
  <style>
    :root {
      --green: #228B22;
      --green-dark: #1b6d1b;
      --bg: #f8fff8;
      --card: #ffffff;
      --text: #222;
      --border: #e0e0e0;
    }

    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: var(--bg);
      color: var(--text);
      height: 100vh;
      display: flex;
      overflow: hidden;
    }

    /* Left navigation */
    nav {
      background-color: var(--green);
      width: 220px;
      padding-top: 18px;
      display: flex;
      flex-direction: column;
      align-items: center;
      box-shadow: 2px 0 8px rgba(0,0,0,0.08);
      flex-shrink: 0;
    }
    nav .brand {
      color: white;
      font-weight: 700;
      font-size: 22px;
      margin-bottom: 30px;
      letter-spacing: 1px;
    }
    nav ul {
      list-style: none;
      width: 100%;
      padding: 0;
      margin: 0;
    }
    nav ul li {
      width: 100%;
      padding: 16px 20px;
      text-align: left;
      color: white;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.2s;
      user-select: none;
      border-left: 4px solid transparent;
    }
    nav ul li:hover { background: var(--green-dark); }
    nav ul li.active { 
        background: var(--green-dark); 
        border-left: 4px solid #fff;
    }

    /* Main column */
    .main-col {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
      height: 100vh;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 14px 25px;
      background: white;
      color: var(--text);
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
      z-index: 10;
    }
    header .title {
      font-size: 18px;
      font-weight: 700;
      display: flex;
      gap: 12px;
      align-items: center;
    }
    header .logo {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      background: var(--green);
      color: white;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
    }

    header .user-area { display: flex; gap: 15px; align-items: center; }
    header button {
      background: #f0f0f0;
      border: none;
      padding: 8px 15px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
    }
    header #logoutBtn { background: #ffeded; color: #d32f2f; }

    main {
      padding: 30px;
      overflow-y: auto;
      flex: 1;
    }

    .section {
      display: none;
      max-width: 900px;
      margin: 0 auto;
    }

    /* Card & Forms */
    .card {
      background: var(--card);
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      margin-bottom: 20px;
      border: 1px solid var(--border);
    }

    h2 { color: var(--green); margin-top: 0; margin-bottom: 20px; }
    
    label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; }
    input, select, textarea {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid var(--border);
      border-radius: 8px;
      font-size: 15px;
    }

    .btn-primary {
      background: var(--green);
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 8px;
      font-weight: 700;
      cursor: pointer;
      width: 100%;
      transition: background 0.2s;
    }
    .btn-primary:hover { background: var(--green-dark); }

    /* Feed Items */
    .feed-item {
      background: white;
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 15px;
      border-left: 6px solid var(--green);
      box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .feed-header { display: flex; justify-content: space-between; align-items: flex-start; }
    .category-tag { 
        background: #e8f5e9; 
        color: var(--green); 
        padding: 4px 10px; 
        border-radius: 4px; 
        font-size: 12px; 
        font-weight: 700; 
    }
    .price-tag { font-weight: 800; color: var(--green); font-size: 18px; }

    footer {
      padding: 15px 30px;
      background: white;
      border-top: 1px solid var(--border);
      display: flex;
      justify-content: space-between;
      font-size: 13px;
      color: #777;
    }
	#aboutSection h3{
		display: inline;
	}
	#aboutSection span
	{
		color:red;
		text-decoration:underline;
		font-weight:bold;
	}
  </style>
</head>
<body>

  <nav>
    <div class="brand">Quickivity</div>
    <ul>
      <li id="clientBtn" class="active">Client Mode</li>
      <li id="creatorBtn">Creator Mode</li>
      <li id="faqBtn">FAQ</li>
      <li id="aboutBtn">About</li>
      <li id="profileBtn">Profile</li>
    </ul>
  </nav>

  <div class="main-col">
    <header>
      <div class="title">
        <div class="logo">Q</div>
        <div>Dashboard</div>
      </div>
      <div class="user-area">
        <span id="welcomeText">Hi, User</span>
        <button id="logoutBtn">Logout</button>
      </div>
    </header>

    <main>
      <div id="clientSection" class="section" style="display:block;">
        <h2>Post New Request</h2>
        <div class="card">
            <label>Project Header</label>
            <input type="text" id="jobHeader" name="jobHeader" placeholder="e.g. Modern Landing Page for Cafe">

            <label>Category</label>
            <select id="jobCategory" name="jobCategory">
                <option value="Frontend Templates">Frontend Templates</option>
                <option value="Architectural Designs">Architectural Designs</option>
                <option value="Graphic Design">Graphic Design</option>
                <option value="Pamphlet Designs">Pamphlet Designs</option>
                <option value="Others">Others</option>
            </select>

            <label>Description & Requirements</label>
            <textarea id="jobDetails" name="jobDetails" rows="4" placeholder="Describe what you need in detail..."></textarea>

            <label>Budget (USD)</label>
            <input type="number" id="jobBudget" name="jobBudget" placeholder="50">

            <button class="btn-primary" id="submitPostBtn">Post Request to Marketplace</button>
        </div>
      </div>

      <div id="creatorSection" class="section">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2>Available Gigs</h2>
            <button onclick="loadGigs()" style="background:none; color:var(--green); font-weight:bold; border:none; cursor:pointer;">↻ Refresh Feed</button>
        </div>
        <div id="gigFeed">
            </div>
      </div>

      <div id="faqSection" class="section">
	<h2>FAQ</h2>
	<h4>How it works...</h4>
	<ul>
		<li>An user is both client and creator, he/she can request the task to be completed and pay the price and completes someone else task and gets paid for it.</li>
		<li>This website serves an important bridge to bring clients and creator closer.</li>
		<li>Clients can outsource their work to the creators to save their precious time and reduce the workload.</li>
		<li>Creators can build stuff and earn the money.</li>
		<li>This website ensures proper execution of contract and payment online.</li>
	</ul>
	</div>
      <div id="aboutSection" class="section">
	<h2>About</h2>
	<h3 id="first">Quick</h3><h3 id="second"> + </h3><h3 id="third">Creativity</h3><h3 id="fourth"> = </h3><h3 id="fifth">Quickivity</h3>
	<p>Quickivity is a fast marketplace where it serves both client and creator. Client can outsource their work to freelancers and Creators can earn more money apart from their jobs and this can be lifeline for unemployed and practitioners.</p>
	<p>Therefore our motto is achieving objectives i.e.<span>Quick</span> means the given task must be done quickly within 24 hrs after contract begins, and <span>Creativity</span> means creators must showcase their creativity and talent to make their work more sounding and appealing.</p>
      </div>
      <div id="profileSection" class="section">
	<h2>Profile</h2>
	<div id="profileContent">
		
	</div>
      </div>
    </main>

    <footer>
      <div>© 2025 Quickivity - Quick + Creativity</div>
      <div>Unified User Account</div>
    </footer>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function(){
      // 1. Auth Guard
      if(localStorage.getItem('isLoggedIn') !== 'true') {
          window.location.href="login.html";	
      }

      // 2. Load User Context
      const myName = localStorage.getItem("userName");
      const myEmail = localStorage.getItem("userEmail");
      $('#welcomeText').text(myEmail ? `Hi ${myEmail}` : "");

      // 3. Navigation Switching
      $('nav ul li').click(function () {

    // Nav UI
    $('nav ul li').removeClass('active');
    $(this).addClass('active');

    // Hide all sections
    $('.section').hide();

    const sectionId = this.id.replace('Btn', 'Section');
    const $section = $('#' + sectionId);

    // Show section with fade
    $section.fadeIn(300);

    localStorage.setItem('activeMode', this.id);

    /* -------------------------
       SECTION-SPECIFIC LOGIC
    --------------------------*/

    // Creator Mode → Load gigs
    if (this.id === 'creatorBtn') {
        loadGigs();
    }

    // Profile → Load & animate profile
    if (this.id === 'profileBtn') {
        const email = localStorage.getItem("userEmail");

        $.get("api/get_profile.php", { email }, function (data) {
            const html = `
                <div class="card">
                    <p><strong>Name:</strong> ${data.user.name}</p>
                    <p><strong>Email:</strong> ${data.user.email}</p>
                    <p><strong>Gender:</strong> ${data.user.gender}</p>
                    <p><strong>Age:</strong> ${data.user.age}</p>
                    <hr>
                    <p><strong>Projects Posted:</strong> ${data.stats.posted}</p>
                </div>
            `;

            $('#profileContent').hide().html(html).fadeIn(500);
        });
    }

    // About → Animated text
    if (this.id === 'aboutBtn') {
        const items = $("#first,#second,#third,#fourth,#fifth");
        items.hide();

        let i = 0;
        function showNext() {
            if (i < items.length) {
                $(items[i]).fadeIn(600, showNext);
                i++;
            }
        }
        showNext();
    }

    // FAQ → Animated list
    if (this.id === 'faqBtn') {
        const faqItems = $("#faqSection ul li");
        faqItems.hide();

        let i = 0;
        function showFaq() {
            if (i < faqItems.length) {
                $(faqItems[i]).fadeIn(400, showFaq);
                i++;
            }
        }
        showFaq();
    }
});

		
      // 4. Submit Job (Client Mode)
      $('#submitPostBtn').click(function(){
          const data = {
              u_name: myName,
              u_email: myEmail,
              header: $('#jobHeader').val(),
              category: $('#jobCategory').val(),
              details: $('#jobDetails').val(),
              budget: $('#jobBudget').val()
          };

          if(!data.header || !data.budget) {
              alert("Please fill in the Header and Budget.");
              return;
          }

          $.post("api/post_gig.php", data, function(res){
              if(res.trim() === "success") {
                  alert("Project Posted Successfully!");
                  // Reset form
                  $('#jobHeader, #jobDetails, #jobBudget').val('');
                  // Auto-switch to see the feed
                  $('#creatorBtn').click();
              } else {
                  alert("Error posting gig. Check database.");
              }
          });
      });

      // 5. Load Gigs (Creator Mode)
      window.loadGigs = function() {
          $('#gigFeed').html('<p>Loading latest requests...</p>');
          $.get("api/get_gigs.php", function(data){
              let html = "";
              if(data.length === 0) {
                  html = "<p>No open requests found. Check back later!</p>";
              } else {
                  data.forEach(gig => {
                      const isMine = gig.posted_by_email === myEmail;
                      html += `
                        <div class="feed-item">
                            <div class="feed-header">
                                <div>
                                    <span class="category-tag">${gig.job_category}</span>
                                    <h3 style="margin:10px 0 5px 0;">${gig.job_header}</h3>
                                </div>
                                <div class="price-tag">$${gig.budget}</div>
                            </div>
                            <p style="font-size:14px; color:#555;">${gig.job_details}</p>
                            <hr style="border:0; border-top:1px solid #eee; margin:15px 0;">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <small>Posted by: <b>${gig.name}</b></small>
                                ${isMine ? 
                                    '<span style="color:#999; font-size:12px;">(Your Request)</span>' : 
                                    `<button onclick="acceptGig(${gig.id})" style="background:var(--green); color:white; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:bold;">Accept & Sign</button>`
                                }
                            </div>
                        </div>`;
                  });
              }
              $('#gigFeed').hide().html(html).fadeIn();
          }, "json");
      };

      // 6. Action: Accept Gig
    // Function to Accept a Gig
	window.acceptGig = function(id) {
		if(confirm("Do you want to accept this task?")) {
			const creatorEmail = localStorage.getItem("userEmail");
			$.post("api/accept_gig.php", { id: id, creator_email: creatorEmail }, function(res) {
				if(res.trim() === "success") {
					alert("Gig accepted! Check your dashboard.");
					loadGigs(); // Refresh the list
				} 
				else {
					alert(res);
				}
			});
		}
	};

	// Function to Load Profile Data
	$('#profileBtn').click(function() {
		const email = localStorage.getItem("userEmail");
		$.get("api/get_profile.php", { email: email }, function(data) {
			let html = `
				<div class="card">
					<p><strong>Name:</strong> ${data.user.name}</p>
					<p><strong>Email:</strong> ${data.user.email}</p>
					<p><strong>Gender:</strong> ${data.user.gender}</p>
					<p><strong>Age:</strong> ${data.user.age}</p>
					<hr>
					<p><strong>Projects Posted:</strong> ${data.stats.posted}</p>
				</div>
			`;
			$('#profileContent').html(html);
			$("#profileContent").hide();
			$("#profileContent").fadeIn("slow",function(){
				console.log("Profile fade in event worked");
			});
		});
	});

      // 7. Logout
      $('#logoutBtn').click(function(){
          localStorage.clear();
          window.location.href = "login.html";
      });

      // Restore last active mode
      let lastMode = localStorage.getItem("activeMode") || "clientBtn";
      $('#' + lastMode).click();

		/*$("#first,#second,#third,#fourth,#fifth").hide();
		$("#first").fadeIn(1000,function(){
			console.log("First worked");
			$("#second").fadeIn(1000,function(){
				console.log("Second worked");
				$("#third").fadeIn(1000,function(){
					console.log("Third worked");
					$("#fourth").fadeIn(1000,function(){
						console.log("Fourth worked");
						$("#fifth").fadeIn(1000,function(){
							console.log("Fifth worked");
						});
					});	
				});
			});
		});
	
		$("#faqSection ul li").hide();
		$("#faqSection ul li:eq(0)").fadeIn(1000,function(){
			console.log("First worked");
			$("#faqSection ul li:eq(1)").fadeIn(1000,function(){
				console.log("Second worked");
				$("#faqSection ul li:eq(2)").fadeIn(1000,function(){
					console.log("Third worked");
					$("#faqSection ul li:eq(3)").fadeIn(1000,function(){
						console.log("Fourth worked");
						$("#faqSection ul li:eq(4)").fadeIn(1000,function(){
							console.log("Fifth worked");
						});
					});
				});
			});
		});*/
    });
  </script>
</body>
</html>