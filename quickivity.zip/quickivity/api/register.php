<?php
	//register.php//
	$host = "localhost";
	$user = "root";
	$db = "quickivity";
	$password = "";
	$conn = mysqli_connect($host,$user,$password,$db) or die("Connection failed");
	$name = $_POST["u-name"];
	$gender = $_POST["u-gender"];
	$age = $_POST["u-age"];
	$email = $_POST["u-email"];
	$pass = $_POST["u-pass"];
	$hashed = password_hash($pass,PASSWORD_DEFAULT);
	$check = $conn->prepare("SELECT * FROM users WHERE email = ?");
	$check->bind_param("s",$email);
	$check->execute();
	$check->store_result();
	if($check->num_rows > 0)
	{
		die("Email already registered");
	}
	$query1 = $conn->prepare("INSERT INTO users (name,gender,age,email,password) VALUES (?,?,?,?,?)");
	$query1->bind_param("ssiss",$name,$gender,$age,$email,$hashed);
	if($query1->execute())
	{
		echo "success";
	}
	else{
		echo "error_insert";
	}
	$query1->close();
	$conn->close();
?>