<?php
// Enable detailed error reporting for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = mysqli_connect("localhost", "root", "", "quickivity");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $gig_id = intval($_POST['id'] ?? 0);
        $creator_email = trim($_POST['creator_email'] ?? '');

        if ($gig_id === 0 || $creator_email === "") {
            echo "invalid_data";
            exit;
        }

        // 1. Verify the gig exists and belongs to someone else
        // We use lowercase 'open' - check if your DB uses 'Open' or 'open'
        $check = $conn->prepare("SELECT client_email FROM gigs WHERE id = ? AND status = 'open'");
        $check->bind_param("i", $gig_id);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows === 0) {
            echo "Gig not found or already accepted";
            exit;
        }

        $row = $res->fetch_assoc();
        if ($row['client_email'] === $creator_email) {
            echo "You cannot accept your own gig";
            exit;
        }

        // 2. The Update (Line 44 area)
        // Ensure there are no hidden characters in this string
        $stmt = $conn->prepare("UPDATE gigs SET status = 'accepted', creator_email = ? WHERE id = ? AND status = 'open'");
        $stmt->bind_param("si", $creator_email, $gig_id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                echo "success";
            } else {
                echo "Update failed: Row may have changed status";
            }
        }
        $stmt->close();
    }
    $conn->close();

} catch (Exception $e) {
    // This sends the SPECIFIC database error to your Javascript alert
    echo "SQL Error: " . $e->getMessage();
}
?>