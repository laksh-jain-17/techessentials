<?php
$conn = mysqli_connect("localhost", "root", "");
if (!$conn) {
    die("Database connection failed");
}

/* Create DB */
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS quickivity");
mysqli_select_db($conn, "quickivity");

/* USERS TABLE */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    gender VARCHAR(10),
    age INT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    failed_attempts INT DEFAULT 0,
    locked_until DATETIME DEFAULT NULL
)
");

/* GIGS TABLE */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS gigs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    client_email VARCHAR(255) NOT NULL,
    job_header VARCHAR(150) NOT NULL,
    job_category VARCHAR(100) NOT NULL,
    job_details TEXT NOT NULL,
    budget INT NOT NULL,
    status VARCHAR(30) DEFAULT 'open',
    creator_email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (client_email),
    INDEX (status)
)
");

/* MARKET TABLE */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS market (
    id INT AUTO_INCREMENT PRIMARY KEY,
    creator_email VARCHAR(255) NOT NULL,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price INT NOT NULL,
    file_path VARCHAR(255) NOT NULL
)
");

/* CONTRACT ASSIGNMENTS */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS contract_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gig_id INT NOT NULL,
    creator_email VARCHAR(255) NOT NULL,
    signed_at DATETIME DEFAULT NULL,
    start_time DATETIME DEFAULT NULL,
    expires_at DATETIME DEFAULT NULL,
    status VARCHAR(30) DEFAULT 'pending',
    FOREIGN KEY (gig_id) REFERENCES gigs(id)
)
");

/* CONTRACT SUBMISSIONS */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS contract_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gig_id INT NOT NULL,
    creator_email VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    message TEXT,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
");

/* RATINGS */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gig_id INT NOT NULL,
    client_email VARCHAR(255),
    creator_email VARCHAR(255),
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
");

echo "Initialization complete";
mysqli_close($conn);
?>
