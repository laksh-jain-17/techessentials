<?php
// api/get_profile.php
header('Content-Type: application/json');
$host = "localhost";
$user = "root";
$password = "";
$db = "quickivity";

$conn = mysqli_connect($host, $user, $password, $db);

$email = $_GET['email'];

// Fetch User Info
$stmt = $conn->prepare("SELECT name, gender, age, email FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$user_data = $stmt->get_result()->fetch_assoc();

// Count Gigs posted by this user
$stmt2 = $conn->prepare("SELECT COUNT(*) as total FROM gigs WHERE client_email = ?");
$stmt2->bind_param("s", $email);
$stmt2->execute();
$posted_count = $stmt2->get_result()->fetch_assoc()['total'];

$response = [
    "user" => $user_data,
    "stats" => ["posted" => $posted_count]
];

echo json_encode($response);
mysqli_close($conn);
?>