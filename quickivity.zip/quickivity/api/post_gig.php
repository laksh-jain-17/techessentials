<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "quickivity";

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("DB connection failed");
}

// Read POST data (MATCHES main.html)
$client_name  = trim($_POST['u_name'] ?? '');
$client_email = trim($_POST['u_email'] ?? '');
$job_header   = trim($_POST['header'] ?? '');
$job_category = trim($_POST['category'] ?? '');
$job_details  = trim($_POST['details'] ?? '');
$budget       = trim($_POST['budget'] ?? '');

// Validation
if (
    $client_name === "" ||
    $client_email === "" ||
    $job_header === "" ||
    $job_category === "" ||
    $job_details === "" ||
    $budget === "" ||
    !is_numeric($budget)
) {
    echo "invalid";
    exit;
}

// Insert
$query = "
INSERT INTO gigs
(client_name, client_email, job_header, job_category, job_details, budget, status)
VALUES
(?, ?, ?, ?, ?, ?, 'open')
";

$stmt = $conn->prepare($query);
$stmt->bind_param(
    "sssssi",
    $client_name,
    $client_email,
    $job_header,
    $job_category,
    $job_details,
    $budget
);

if ($stmt->execute()) {
    echo "success";
} else {
    echo $stmt->error;
}

$stmt->close();
$conn->close();
?>
