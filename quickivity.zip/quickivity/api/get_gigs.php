<?php
header('Content-Type: application/json');

$conn = mysqli_connect("localhost", "root", "", "quickivity");
if (!$conn) {
    echo json_encode([]);
    exit;
}

$query = "
SELECT 
    gigs.id,
    gigs.client_name,
    gigs.client_email,
    gigs.job_header,
    gigs.job_category,
    gigs.job_details,
    gigs.budget,
    gigs.status,
    gigs.created_at
FROM gigs
WHERE gigs.status = 'open'
ORDER BY gigs.created_at DESC
";

$result = mysqli_query($conn, $query);
$gigs = [];

while ($row = mysqli_fetch_assoc($result)) {
    $gigs[] = $row;
}

echo json_encode($gigs);
mysqli_close($conn);
?>
