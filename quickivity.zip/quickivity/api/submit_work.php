<?php
session_start();
$conn=mysqli_connect("localhost","root","","quickivity");

$gig=$_POST['gig_id'];
$msg=$_POST['message'];
$creator=$_SESSION['user_email'];

$path="uploads/".time()."_".$_FILES['work']['name'];
move_uploaded_file($_FILES['work']['tmp_name'],$path);

$stmt=$conn->prepare("
INSERT INTO contract_submissions (gig_id,creator_email,file_path,message)
VALUES (?,?,?,?)
");
$stmt->bind_param("isss",$gig,$creator,$path,$msg);
$stmt->execute();

$conn->query("UPDATE gigs SET status='submitted' WHERE id=$gig");

echo "submitted";
?>