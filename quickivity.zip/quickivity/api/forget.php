<?php 
	//forget.php//
	$host = "localhost";
	$user = "root";
	$db = "quickivity";
	$password = "";
	$conn = mysqli_connect($host,$user,$password,$db) or die("Database connected unsuccessfully");
	$email = $_POST["email"];
	$pass = $_POST["password"];
	$hashed = password_hash($pass,PASSWORD_DEFAULT);
	$check = $conn->prepare("SELECT * FROM users WHERE email = ?");
	$check->bind_param("s",$email);
	$check->execute();
	$result = $check->get_result();
	if($result->num_rows === 0)
	{
		echo "Email not found";
		exit;
	}
	$query1 = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
	$query1->bind_param("ss",$hashed,$email);
	if($query1->execute())
	{
		echo "success";
	}
	else{
		echo "failed";
	}
?>