<?php
session_start();
$conn=mysqli_connect("localhost","root","","quickivity");
$creator=$_SESSION['user_email'];

$q=$conn->prepare("
SELECT g.*, c.expires_at
FROM gigs g
JOIN contract_assignments c ON g.id=c.gig_id
WHERE c.creator_email=? AND c.status='active'
");
$q->bind_param("s",$creator);
$q->execute();

$res=[];
$r=$q->get_result();
while($row=$r->fetch_assoc()) $res[]=$row;

echo json_encode($res);
?>