<?php
session_start();
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

$conn = mysqli_connect("localhost", "root", "", "quickivity");
if (!$conn) {
    die("DB error");
}

$email = trim($_POST["email"] ?? "");
$pass  = trim($_POST["password"] ?? "");

/* Fetch user */
$stmt = $conn->prepare("
    SELECT id, name, password, failed_attempts, locked_until
    FROM users
    WHERE email = ?
");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if (!$user = $result->fetch_assoc()) {
    echo "invalid";
    exit;
}

/* Check account lock */
if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
    echo "locked";
    exit;
}

/* Verify password */
if (!password_verify($pass, $user['password'])) {

    $attempts = $user['failed_attempts'] + 1;

    if ($attempts >= 3) {
        $lockUntil = date("Y-m-d H:i:s", strtotime("+10 minutes"));
        $upd = $conn->prepare("
            UPDATE users
            SET failed_attempts = ?, locked_until = ?
            WHERE email = ?
        ");
        $upd->bind_param("iss", $attempts, $lockUntil, $email);
    } else {
        $upd = $conn->prepare("
            UPDATE users
            SET failed_attempts = ?
            WHERE email = ?
        ");
        $upd->bind_param("is", $attempts, $email);
    }

    $upd->execute();
    echo "invalid";
    exit;
}

/* Reset failed attempts on success */
$reset = $conn->prepare("
    UPDATE users
    SET failed_attempts = 0, locked_until = NULL
    WHERE email = ?
");
$reset->bind_param("s", $email);
$reset->execute();

/* Generate OTP */
$otp = rand(100000, 999999);
$_SESSION['login_otp'] = $otp;
$_SESSION['otp_time']  = time();
$_SESSION['temp_user_id']   = $user['id'];
$_SESSION['temp_user_name'] = $user['name'];
$_SESSION['temp_user_email'] = $email;

/* DEV LOG (safe on localhost) */
error_log("DEV OTP for $email : $otp");

/* Send email (may be blocked by antivirus / SMTP config) */
$subject = "Quickivity Login Verification Code";
$message = "Your verification code is: $otp\n\nThis code is valid for 5 minutes.";
$headers = "From: no-reply@quickivity.com";

@mail($email, $subject, $message, $headers);

/* Tell frontend to show OTP input */
echo "captcha_sent";
?>