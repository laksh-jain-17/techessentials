<?php
$conn=mysqli_connect("localhost","root","","quickivity");

$stmt=$conn->prepare("
INSERT INTO ratings (gig_id,client_email,creator_email,rating,comment)
VALUES (?,?,?,?,?)
");
$stmt->bind_param(
 "issis",
 $_POST['gig_id'],
 $_POST['client_email'],
 $_POST['creator_email'],
 $_POST['rating'],
 $_POST['comment']
);
$stmt->execute();

echo "rated";
?>