<?php
session_start();
$conn=mysqli_connect("localhost","root","","quickivity");

$gig_id=$_POST['id'];
$creator=$_SESSION['user_email'];

$now=date("Y-m-d H:i:s");
$expires=date("Y-m-d H:i:s",strtotime("+24 hours"));

$stmt=$conn->prepare("
UPDATE contract_assignments
SET signed_at=?, start_time=?, expires_at=?, status='active'
WHERE gig_id=? AND creator_email=?
");
$stmt->bind_param("sssds",$now,$now,$expires,$gig_id,$creator);

$conn->query("UPDATE gigs SET status='ongoing' WHERE id=$gig_id");

echo "success";
?>