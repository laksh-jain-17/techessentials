<?php
/* 🔥 FORCE SESSION COOKIE TO ROOT 🔥 */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',      // <-- THIS FIXES IT
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

/* OTP not generated */
if (!isset($_SESSION['login_otp'], $_SESSION['otp_time'])) {
    echo "expired";
    exit;
}

/* OTP expired (5 minutes) */
if (time() - $_SESSION['otp_time'] > 300) {
    unset($_SESSION['login_otp'], $_SESSION['otp_time']);
    echo "expired";
    exit;
}

$otp = trim($_POST["otp"] ?? "");

/* Verify OTP */
if ($otp === strval($_SESSION['login_otp'])) {

    /* Promote temp session to full login */
    $_SESSION['user_id']    = $_SESSION['temp_user_id'];
    $_SESSION['user_name']  = $_SESSION['temp_user_name'];
    $_SESSION['user_email'] = $_SESSION['temp_user_email'];

    /* Cleanup temp data */
    unset(
        $_SESSION['login_otp'],
        $_SESSION['otp_time'],
        $_SESSION['temp_user_id'],
        $_SESSION['temp_user_name'],
        $_SESSION['temp_user_email']
    );

    session_write_close(); // 🔒 ensure session is saved

    echo "success";
} else {
    echo "invalid";
}
?>