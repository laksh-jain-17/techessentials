<?php
$conn=mysqli_connect("localhost","root","","quickivity");
$id=$_GET['id'];

$q=$conn->prepare("SELECT * FROM gigs WHERE id=?");
$q->bind_param("i",$id);
$q->execute();
$res=$q->get_result()->fetch_assoc();

echo json_encode($res);
?>